import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;

import javax.swing.JPanel;
import javax.swing.JButton;
import java.io.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Classe Affichage heritant de JPanel, un conteneur permettant l'affichage du programme.   
 */

public class Affichage extends JPanel{
	private static final long serialVersionUID = 1L;
    
    /**
    * Méthode gérant l'affichage sur l'écran
    */
	public void paintComponent(Graphics g){
		BufferedReader br = null;
		double pX;
		double pY;
		ArrayList<Double> X = new ArrayList<Double>();
		ArrayList<Double> Y = new ArrayList<Double>();
		Color couleur = new Color(0,0,0);
		try{
			//Lecture des donnees du fichier stocke dans la variable br.
			br = new BufferedReader(new FileReader("DescriptionFigureGolf2.txt"));
			String line;
			Pattern pattern = Pattern.compile("(\\d++\\.?\\d*)(,)(\\d++\\.?\\d*)");
			Pattern pCol = Pattern.compile("([A-Z])");
		
			//Lecture de la premiere ligne
			String text = br.readLine();
			//System.out.println(text);
		    int nbPoly = Integer.parseInt(text);
		    int compteur = 0;
			//Lecture ligne par ligne des donnees du fichier a partir de la ligne 2, 
			//les lignes sont stockees dans la variable 'line'
			while ((line = br.readLine()) != null && compteur < nbPoly) {		
			// TODO extraire les entiers des lignes pour creer les points, puis les triangles et pour finir les polygones.
		        Matcher m =  pattern.matcher(line);
		        Matcher color = pCol.matcher(line);
		        while (m.find()) {
		        	//System.out.println("Valeur de m.group(1) : " + m.group(1));
				    pX = Double.parseDouble(m.group(1));
				    X.add(pX);
				    pY = Double.parseDouble(m.group(3));
				    Y.add(pY);
		        }
		        
		        while (color.find()){
		        	//System.out.println("Couleur : " + color.group(1));
		        	couleur = getCol(color.group(1));
		        }
		        
		        if (!m.find()) {
			        int[] cX = new int[X.size()+1];
					int[] cY = new int[Y.size()+1];
					
					//System.out.println("Liste des points X : ( " + (X.size()+1) +" )");
					for(int q = 0; q < X.size(); q++){
						cX[q] = (int) ((X.get(q)+10)*50);
						//System.out.println((cX[q]/50)-10);
					}
					
					cX[X.size()] = cX[0];
					//System.out.println("Liste des points Y :( " + (Y.size()+1) +" )");
					for(int d = 0; d < Y.size(); d++){
						cY[d] = (int) ((-Y.get(d)+10)*50);
						//System.out.println(((cY[d]/50)-10)*-1);
					}
					cY[Y.size()] = cY[0];
					
					//Creation du polygone correspondant a un ensemble de points
					g.setColor(couleur);
					//System.out.println("Couleur modifie en :  " + couleur);
					g.fillPolygon(cX, cY, cY.length);
					g.setColor(Color.BLACK);
					g.drawPolygon(cX, cY, cY.length);
					X.clear();
					Y.clear();
					compteur++;
		        }
			}
			
			while ((line = br.readLine()) != null ) {
				pattern = Pattern.compile("([(])(\\d++\\.?\\d*)(,)(\\d++\\.?\\d*)([)])([,])"
						+ "([(])(\\d++\\.?\\d*)(,)(\\d++\\.?\\d*)([)])");
				Matcher m = pattern.matcher(line);
				//Ajout debut et fin de chaque trace
		        while (m.find())
		        {
		        	int posX = (int) Double.parseDouble((m.group(2)));
		        	int posY = (int) Double.parseDouble((m.group(4)));
		        	g.setColor(Color.YELLOW);
		        	g.fillOval((posX+10)*50,((-posY+10)*50),10,10);
		        	g.setColor(Color.BLACK);
		        	g.drawOval((posX+10)*50,((-posY+10)*50),10,10);
		        	posX = (int) Double.parseDouble((m.group(8)));
		        	posY = (int) Double.parseDouble((m.group(10)));
		        	g.setColor(Color.RED);
		        	g.fillOval((posX+10)*50,((-posY+10)*50),10,10);
		        	g.setColor(Color.BLACK);
		        	g.drawOval((posX+10)*50,((-posY+10)*50),10,10);
		        }
				
			}

			
			br.close();
		}catch(FileNotFoundException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(IOException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 
	
	public Color getCol(String couleur)
	{
		Color col = new Color(0,0,0);
		switch (couleur) {
			case "C": 	col = new Color(160,240,64);	//Vert clair
						break;
			case "B": 	col = new Color(91,155,213);	//Bleu
						break;
			case "V": 	col = new Color(0,176,80);		//Vert
						break;
			case "S": 	col = new Color(0,125,0); 		//Vert Sapin
						break;
			case "J": 	col = new Color(201,187,103);	//Beige
						break;
		}
		return col;
	}
	
}
