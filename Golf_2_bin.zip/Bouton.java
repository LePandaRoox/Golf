import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Bouton extends JButton implements MouseListener{

	private String name;

	public Bouton(String str){
    	super(str);
    	this.name = str;
		//this.addMouseListener(this);
    }



	//Méthode appelée lors du clic de souris
  	public void mouseClicked(MouseEvent event) {
	System.out.println("TESDTEGSGRqsd");
	}


  	//Méthode appelée lors du survol de la souris
  	public void mouseEntered(MouseEvent event) { 
	System.out.println("TESDTEGSGRqsd");
	}


  	//Méthode appelée lorsque la souris sort de la zone du bouton
  	public void mouseExited(MouseEvent event) { 
	System.out.println("TESDTEGSGRqsd");
	}


  	//Méthode appelée lorsque l'on presse le bouton gauche de la souris
 	public void mousePressed(MouseEvent event) { 
	System.out.println("TESDTEGSGRqsd");
	}


 	//Méthode appelée lorsque l'on relâche le clic de souris
  	public void mouseReleased(MouseEvent event) {
	System.out.println("TESDTEGSGRqsd");
	} 

}
