/**
 *
 * @author 	Matthieu Gayraud
 * 			<br>Benjamin Brault
 *
 * <p>Les instances de la classe Droite représente des droites
 * définies par une équation paramétrique.
 *
 */
public class Droite {

	private double a,b,c;

	/**
	 * Crée une droite d'équation x = y
	 */
	public Droite() {
		a = 1;
		b = -1;
		c = 0;
	}

	/**
	 * Construit une droite en donnant une équation paramétrique la
	 * définissant.<br>Complexité : O(1)
	 * @param na
	 * @param nb
	 * @param nc
	 */
	public Droite(double na, double nb, double nc) {
		a = na;
		b = nb;
		c = nc;
	}

	/**
	 * Construit une droite à partir de deux points
	 * <br>Complexité : O(1)
	 * @param p1 Premier point de la droite
	 * @param p2 Second point de la droite
	 */
	public Droite (Point p1, Point p2) {
		a = -(p2.getY() - p1.getY());
		b = p2.getX() - p1.getX();
		c = -((a*p1.getX()+b*p1.getY()));
	}

	/**
	 * Construit une copie de la droite d
	 * <br>Complexité : O(1)
	 * @param d Droite que l'on veut copier
	 */
	public Droite (Droite d) {
		a = d.getA();
		b = d.getB();
		c = d.getC();
	}

	//TODO : Finir doc sur getter
	/**
	 * @return
	 */
	public double getA()
	{ return a; }

	/**
	 * @return
	 */
	public double getB()
	{ return b; }

	/**
	 * @return
	 */
	public double getC()
	{ return c; }

	/**
	 * Retourne sous forme de chaîne de caractère une équation
	 * définissant la droite
	 */
	public String toString() {
		return a +"x + " + b + "y + " + c + " = 0 ";
	}

	/**
	 * Calcul si deux droites sont confondues
	 * <br>Complexité : O(1)
	 * @param d Droite avec laquelle on compare les équations paramétriques
	 * @return vrai si les droites sont confondues, faux sinon.
	 */
	public boolean confondu(Droite d) {
		return d.getA()/getA() == d.getB()/getB() &&
			   d.getA()/getA() == d.getC()/getC();
	}

	/**
	 * Calcul si deux droites s'intersectent
	 * <br>Complexité : O(1)
	 * @param d Droite avec laquelle on test s'il y a intersection
	 * @return  Vrai si les droites se croisent, faux si elles sont confondu
	 * 			ou si elles ne se croisent pas
	 */
	public boolean intersection(Droite d) {
		if (confondu(d))
			return false;
		if (getA()/d.getA() == getB()/d.getB() && getA()/d.getA() != getC()/d.getC())
			return false;
		return true;
	}

	//TODO: Modifier fonctionnement, deux droites peuvent être identiques
	//et avoir des coefficient différent (modulo une constante)
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null)
			return false;
		if (!(o instanceof Droite))
			return false;
		Droite d = (Droite) o;
		return getA() == d.getA() &&
			   getB() == d.getB() &&
			   getC() == d.getC();
	}

	/**
	 * Calcule le point d'intersection entre deux droites.
	 * <br>Complexité : O(1)
	 * @pre La droite d doit être en intersection avec l'objet
	 * @param d Droite avec laquelle on cherche un point d'intersection
	 * @return Le point d'intersection
	 * @throws IllegalArgumentException si les droites de s'intersectent pas
	 */
	public Point pointIntersection(Droite d) {
		if (!intersection(d)){
			throw new IllegalArgumentException("Les droites " + this + " et " + d +
					"doivent s'intersecter");
		}
		double l1 = getA();
		double l2 = d.getA();

		//Système d'équations
		double d1[] = {l2*getA(), l2*getB(), l2*getC()};
		double d2[] = {l1*d.getA(),l1*d.getB(),l1*d.getC()};

		//L2 <- L2 - L1
		d2[0] -= d1[0];
		d2[1] -= d1[1];
		d2[2] -= d1[2];

		//Resolution du système d'équation
		d2[1] = -d2[2]/d2[1];
		d1[0] = (-d1[1]*d2[1] - d1[2])/d1[0];

		return new Point(d1[0],d2[1]);
	}

	public boolean appartient(Point p){
		if(((int)((a*p.getX() + c)) == ((int)(b*p.getY())))){
			return true;
		}
		else{
			return false;
		}
	}

    

}
