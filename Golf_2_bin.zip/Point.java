import java.lang.Math;

/**
 * 
 * @author 	Matthieu Gayraud
 * 			<br>Benjamin Brault
 * 
 * <p>Les instances de la classe Point repr�sente 
 */
public class Point {
	
	public static final double eps = 1e-10;
	
	private double x,y;
	
	/**
	 * Initialise un point aux coordonn�es (0;0)
	 */
	public Point(){
		x = 0.0;
		y = 0.0;
	}
	
	/**
	 * Initialise un point avec les coordonn�es en param�tres
	 * @param px Valeur sur l'axe des abscisses
	 * @param py Valeur sur l'axe des ordonn�es
	 */
	public Point(double px, double py) {
		x = px;
		y = py;
	}
	
	/**
	 * @return Valeur de la coordonn�e sur l'axe des abcisses
	 */
	public double getX()
	{ return x; }
	
	/**
	 * @return Valeur de la coordonn�e sur l'axe des ordonn�es
	 */
	public double getY()
	{ return y;}
	
	/**
	 * D�placement d'un point.
	 * @param ax Valeur du d�placement sur l'axe des abcisses.
	 * @param ay Valeur du d�placement sur l'axe des ordonn�es.
	 */
	public void deplacement(double ax, double ay) { 
		x += ax;
		y += ay;
	}
	
	/**
	 * Red�finition de la m�thode "equals"
	 * @param point Point � comparer avec l'objet utilis�
	 * @return  vrai si les coordonn�es x et y sont identiques, 
	 * 			faux sinon
	 */
	public boolean equals(Point point) {
		return (x == point.getX() && y == point.getY());
	}
	
	/**
	 * Retourne une cha�ne de caract�re repr�sentant cet objet Point.
	 */
	@Override
	public String toString() {
		return "(" + x + ";" + y + ") ";
	}
	
	/**
	 * M�thode donnant le demi-plan du point par rapport � la droite d.
	 * <br>Complexit� : O(1).
	 * @param d Droite avec laquelle on compare la position du point.
	 * @return  0 si le point appartient � la droite
	 * 			<br>1 si le point est dans le demi-plan sup�rieur
	 * 			<br>-1 si le point est dans le demi-plan inf�rieur
	 */

	public int demiPlan(Droite d) {
		if (Math.abs(d.getA()*x + d.getB()*y + d.getC()) <= eps)		
			return 0;
		else
		{
			double res = d.getA()*getX() + d.getB()*getY() + d.getC();
			if (res < 0)
				return 1;
			else
				return -1;
		}
	}
    

   /**
    * Affiche le résultat de la droite d'équation d.
    */
   public double resDemiPlan(Droite d){
        return d.getA()*getX() + d.getB()*getY() + d.getC();
   }

    
	

	/**
	 * M�thode testant l'intersection de deux segments cr��e 
	 * par deux points chacun. 
	 * <br>Complexit� : 0(1).
	 * @param a Premier point du segment 1
	 * @param b Second point du segment 1
	 * @param c Premier point du segment 2
	 * @param d Second point du segment 2
	 * @return  Vrai si les deux segments s'intersectent, faux sinon
	 */

	public static boolean intersectionSegment(Point a, Point b, Point c, Point d) {
		//Comparaison des boites de dimensionnement des segment [AB] et [CD]
		if (!(Math.max(a.getX(), b.getX()) >= Math.min(c.getX(), d.getX()) &&
			Math.max(c.getX(), d.getX()) >= Math.min(a.getX(), b.getX()) &&
			Math.max(a.getY(), b.getY()) >= Math.min(c.getY(), d.getY()) &&
			Math.max(c.getY(), d.getY()) >= Math.min(a.getY(), b.getY())))
			return false;
		
		double z1,z2,z3,z4;
		int s1,s2,s3,s4;
		
		// Test si les segments se chevauchent
		//Direction du point c par rapport � b relativement � a
		z1 = (c.getX() - a.getX()) * (b.getY() - a.getY()) -
			 (c.getY() - a.getY()) * (b.getX() - a.getX());
		
		//Direction du point d par rapport � b relativement � a
		z2 = (d.getX() - a.getX()) * (b.getY() - a.getY()) -
			 (d.getY() - a.getY()) * (b.getX() - a.getX());
		
		//Direction du point a par rapport � d relativement � c
		z3 = (a.getX() - c.getX()) * (d.getY() - c.getY()) -
			 (a.getY() - c.getY()) * (d.getX() - c.getX());
		
		//Direction du point b par rapport � d relativement � c
		z4 = (b.getX() - c.getX()) * (d.getY() - c.getY()) -
			 (b.getY() - c.getY()) * (d.getX() - c.getX());
		
		//Valeur li� au sens horaire
		if (z1 < 0)
			s1 = -1;
		else if (z1 > 0)
			s1 = 1;
		else
			s1 = 0;
		
		if (z2 < 0)
			s2 = -1;
		else if (z2 > 0)
			s2 = 1;
		else
			s2 = 0;
		
		if (z3 < 0)
			s3 = -1;
		else if (z3 > 0)
			s3 = 1;
		else
			s3 = 0;
		
		if (z4 < 0)
			s4 = -1;
		else if (z4 > 0)
			s4 = 1;
		else 
			s4 = 0;
		
		//Vrai si les segments se croisent
		return ((s1 * s2 <= 0) && (s3 * s4 <= 0));
	}

	
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null)
			return false;
		if (!(o instanceof Point))
			return false; 
		Point p = (Point) o;
		return this.getX() == p.getX() && this.getY() == p.getY();
	}
}
