import java.util.*;
import java.lang.*;


public class Polygone {
	
	private ArrayList<Point> listPoint = new ArrayList<Point>();
	private int nbPoint;
	
	/**
	 * Constructeur par défault de Polygone, sachant qu'un polygone doit contenir aux moins 3 sommets, 
	 * on ne peut pas définir un constructeur par défault, on le laisse vide.
	 */
	
	public Polygone(){
		nbPoint = listPoint.size();
	}
	
	/**
	 * @param li_Point Liste de point pour la création du polygone en respectant l'ordre trigonométrique.
	 */
	
	public Polygone(ArrayList<Point> li_Point){
		//la liste des points est supérieures à 3 points
		if(li_Point.size() >= 3){
			//On ajoute les points de la liste d'entrée au Polygone
			Iterator<Point> browser = li_Point.iterator();
			while( browser.hasNext()){
				Point p = browser.next();
				listPoint.add(p);
			}
			nbPoint = listPoint.size();
		}
	}
	
    /**
	 * <p>Complexité : O(N)
	 * @param -
	 * @return la description du polygone.
	 */    
	public String toString() {
		System.out.println("Le polygone est composé des points : ");
		for(int i = 0; i<listPoint.size(); i++){
			System.out.println("Point " + i + " : " + listPoint.get(i).toString() + ". \n ");
		}
		return " ";
	}


    /**
	 * 
	 * @return listePoint la liste des points du polygone.
	 */
	public ArrayList<Point> getListPoint(){
		return listPoint;
	}
	
    /**
	 * 
	 * @return nbPoint le nombre de point du polygone.
	 */
	public int getNbPoint(){
		return nbPoint;
	}

    /**
	 * <p>Complexité : O(N)
	 * @param -
	 * @return l'indice du sommet le plus à gauche du polygone.
	 */
    public int sommet_Gauche(){
        int ind = 0;  
        Point pInter = listPoint.get(0);      
        for(int i=1; i < listPoint.size(); i++){
            if(pInter.getX() > listPoint.get(i).getX()){
                ind = i;
            }
        }
        return ind;
    }    


    /**
	 * <p>Complexité : O(N)
	 * @param t Triangle
     * @param i1, i2, i3 l'indice des points du triangles dans la liste des points du polygone
	 * @return l'indice du sommet du polygone appartenant au triangle t, qui est à la plus grande distance de la droite i1,i2 (= côté du triangle).
	 */    
    public int sommet_distance_maximale(Triangle t, int i1, int i2, int i3){
        int n = listPoint.size();
        double d = 0.0;
        double distance = 0.0;
        int j = -1; // valeur par défault de j si aucun point du triangle n'appartient au polygone.
        Point pInter2 = null;
        for(int i=0; i<listPoint.size(); i++){
            if((i != i1) || (i != i2) || (i != i3)){
                pInter2 = listPoint.get(i);
                if(t.contient(pInter2)){
                    d = Math.abs(listPoint.get(i).resDemiPlan(new Droite(t.getB(), t.getC())));
                    if(d > distance){
                        distance = d;
                        j = i;                    
                    }
                }
            }
        }
        return j;
    }

    /**
    * <p>Complexité : O(1)
	* @param i l'indice du point de travail du polygone.
    * @param di entier définissant la distance du point de travail.
    * return le voisin sommet d'un sommet d'un polygone
    * <p>Astuce : à rajouter dans le rapport, utilisation de la formule : (a mod b) ne marche pas pour les nombres négatifs donc utilisation d'une autre formule : (a mod b+b) mod b.
    */

    public int voisin_Sommet(int i, int di){
        return ((i+di)%listPoint.size()+listPoint.size())%listPoint.size();
    }

    /**
	 * <p>Complexité : O(N)
     * @param deb l'indice du point à partir duquel le polygone est créé.
     * @param fin l'indice de fin, le dernier point du polygone.
	 * @return un nouveau polygone.
	 */
    public Polygone nouveau_Polygone(int deb, int fin){
        Polygone poly = new Polygone();   
        int i = deb;    
        while( i != fin){
            poly.listPoint.add(this.listPoint.get(i));
            i = voisin_Sommet(i, 1);
        }
        poly.listPoint.add(this.listPoint.get(fin));
        return poly;
    }
    
    /**
	 * <p>Complexité : O(N)
     * @param p Polygone
     * @param liste_triangle une liste de triangle ou sont stockée les triangles produit par la fonction.
	 * @return liste_triangle ArrayList<Triangle>.
     *TODO : ne marche pas, revoir fonction sommet_distance_maximal
	 */
    public ArrayList<Triangle> trianguler_polygone_recursif(ArrayList<Triangle> liste_triangle){
        //Détermination du point le plus à gauche et ces voisins.
        int i0 = this.sommet_Gauche();
        int i1 = this.voisin_Sommet(i0, 1);
        int i2 = this.voisin_Sommet(i0, -1);
        //System.out.println(i2);
        //Récupération des points
        Point p1 = listPoint.get(i0);
        Point p2 = listPoint.get(i1);
        Point p3 = listPoint.get(i2);
        //Création du triangle
        Triangle t = new Triangle(p1, p2, p3);
        //Détermine le point appartenant au triangle le plus éloignés de ce triangle.
        int j = this.sommet_distance_maximale(t, i0, i1, i2);     
        //En fonction du point, création des autres triangles récursivement  
        if(j == -1){
            //Ajout du triangle dans la liste !
            liste_triangle.add(new Triangle(p1, p2, p3));
            //Création d'un nouveau polygone en supprimant le point d'indice j !
            Polygone Polygone_3 = this.nouveau_Polygone(i1, i2);
            //Appel récursive tant que la liste des points du polygone est supérieur à 3 !
            if(Polygone_3.getListPoint().size() == 3){
                //Ajout du triangle dans la liste !
                liste_triangle.add(new Triangle(Polygone_3.getListPoint().get(0), Polygone_3.getListPoint().get(1), Polygone_3.getListPoint().get(2)));
            }else{
                //Rappel de la fonction avec le reste des points du polygone !
                Polygone_3.trianguler_polygone_recursif(liste_triangle);
            }
        }else{
            //Création de deux nouveaux polygone en fonction du Point j
            Polygone Polygone_1 = this.nouveau_Polygone(i0, j);
            Polygone Polygone_2 = this.nouveau_Polygone(j, i0);
            if(Polygone_1.getListPoint().size() == 3){
                //Ajout du triangle dans la liste !
                liste_triangle.add(new Triangle(Polygone_1.getListPoint().get(0), Polygone_1.getListPoint().get(1), Polygone_1.getListPoint().get(2)));  
            }else{
                Polygone_1.trianguler_polygone_recursif(liste_triangle);
            }
            if(Polygone_2.getListPoint().size() == 3){
                //Ajout du triangle dans la liste !
                liste_triangle.add(new Triangle(Polygone_2.getListPoint().get(0), Polygone_2.getListPoint().get(1), Polygone_2.getListPoint().get(2)));  
            }else{
                Polygone_2.trianguler_polygone_recursif(liste_triangle);
            }
        }
        return liste_triangle;
    }

}

