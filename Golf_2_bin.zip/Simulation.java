import java.util.*;

public class Simulation {
	public static void main(String args[]) {
		
		//Creation de point
		Point a = new Point(1.0,2.0);
		Point b = new Point(4.0,4.0);
		Point c = new Point(2.0,3.0);
		
		//Creation de droite
		Droite d = new Droite(a,b);
		Droite d1 = new Droite(new Point(0,1),new Point(3,3));
		Droite d2 = new Droite(c, b);
		
		/*
		//Test affichage droites
		System.out.println("D   : " +d.toString());
		System.out.println("D1  : " +d1.toString());
		System.out.println("D2  : " +d2.toString());
		*/
		//Test intersection
		//System.out.println("D intersection d1 ? " + d.intersection(d1));
		//System.out.println("D intersection d2 ? " + d.intersection(d2));
		
		//Test point intersection
		//System.out.println(d.pointIntersection(d2));
		
		//Test d'appartenance à un triangle
		Point p1 = new Point(1,0);
		Point p2 = new Point(3,3);
		Point p3 = new Point(6,0);
		
		Point pt0 = new Point(Double.MAX_VALUE,0);
		//System.out.println(pt0);
		Point pt1 = new Point(0.9999999999,0);
		Point pt2 = new Point(8,0);
		Point pt3 = new Point(3,1);
		Triangle t = new Triangle(p1,p2,p3);
		/*System.out.println("t contient le point : " + p1 + " = " + t.contient(p1));
		System.out.println("t contient le point : " + pt1 + " = " + t.contient(pt1));
		System.out.println("t contient le point : " + pt2 + " = " + t.contient(pt2));
		System.out.println("t contient le point : " + pt3 + " = " + t.contient(pt3));
		System.out.println("t contient le point : " +  pt0 + " = " + t.contient(pt0));*/
    
    //--------------------------------------------------------------------------------------------------------
    //Test de la triangularisation d'un polygone :
    //Définition des polygones de test : poly_test_convexe et poly_test_concave.
    System.out.println("Test dans le cas d'un polyfone convexe (= cas simple) :");
    System.out.println("- poly_test_convexe[ (1,1) ; (10,1) ; (12,10) ; (6,15) ; (1,10)] :");

    ArrayList<Point> listePoint = new ArrayList<Point>();
		listePoint.add(new Point(1,1));
		listePoint.add(new Point(10,1));
		listePoint.add(new Point(12,10));
		listePoint.add(new Point(6, 15));
        listePoint.add(new Point(1, 10));

    Polygone poly_test_convexe = new Polygone(listePoint);
    
    //Définition de listeTriangle = null et d'une listeTriangleSortante.    
    ArrayList<Triangle> listeTriangle = new ArrayList<Triangle>();
    ArrayList<Triangle> listeTriangleSortante = new ArrayList<Triangle>();
    
    //Affectation du résultat de la triangularisation à listeTriangleSortante.
    listeTriangleSortante = poly_test_convexe.trianguler_polygone_recursif(listeTriangle);
    
    //Affichage des triangles résultant de la triangularisation du polygone.
    System.out.println("-------------------------------------------------------------------");
    for(int y = 0; y<listeTriangleSortante.size(); y++){
            System.out.println(listeTriangleSortante.get(y).a);
            System.out.println(listeTriangleSortante.get(y).b);
            System.out.println(listeTriangleSortante.get(y).c);            
            System.out.println("-------------------------------------------------------------------");   
    }
    
    //Conditionnelle de vérification pour le cas convexe :

    if((listeTriangleSortante.get(0).a == listePoint.get(0)) && (listeTriangleSortante.get(0).b == listePoint.get(1)) 
        && (listeTriangleSortante.get(0).c == listePoint.get(4)) //Vérification du premier triangle.
        && (listeTriangleSortante.get(1).a == listePoint.get(4)) && (listeTriangleSortante.get(1).b == listePoint.get(1)) 
        && (listeTriangleSortante.get(1).c == listePoint.get(3)) //Vérification du second triangle.
        && (listeTriangleSortante.get(2).a == listePoint.get(1)) && (listeTriangleSortante.get(2).b == listePoint.get(2)) 
        && (listeTriangleSortante.get(2).c == listePoint.get(3))) //Vérification du troisième triangle.
    {      
      System.out.println("Test Réussi !"); 
    }
    else{
        System.out.println("Test Non-Réussi !");
    }

    System.out.println("");
    System.out.println("Test dans le cas d'un polyfone concave (= cas dur) :");
    System.out.println("- poly_test_concave[ (1,1) ; (5,2) ; (10,1) ; (7,5) ; (10,10)] :");

    listePoint.clear();
		listePoint.add(new Point(1,1));
		listePoint.add(new Point(5,2));
		listePoint.add(new Point(10,1));
		listePoint.add(new Point(7, 5));
        listePoint.add(new Point(10, 10));

    Polygone poly_test_concave = new Polygone(listePoint);
    
    //Définition de listeTriangle = null et d'une listeTriangleSortante.    
    listeTriangle.clear();
    listeTriangleSortante.clear();
    
    //Affectation du résultat de la triangularisation à listeTriangleSortante.
    listeTriangleSortante = poly_test_concave.trianguler_polygone_recursif(listeTriangle);
    
    //Affichage des triangles résultant de la triangularisation du polygone.
    System.out.println("-------------------------------------------------------------------");
    for(int y = 0; y<listeTriangleSortante.size(); y++){
            System.out.println(listeTriangleSortante.get(y).a);
            System.out.println(listeTriangleSortante.get(y).b);
            System.out.println(listeTriangleSortante.get(y).c);            
            System.out.println("-------------------------------------------------------------------");   
    }
    
    //Conditionnelle de vérification pour le cas convexe :

    if((listeTriangleSortante.get(0).a == listePoint.get(0)) && (listeTriangleSortante.get(0).b == listePoint.get(1)) 
        && (listeTriangleSortante.get(0).c == listePoint.get(4)) //Vérification du premier triangle.
        && (listeTriangleSortante.get(1).a == listePoint.get(1)) && (listeTriangleSortante.get(1).b == listePoint.get(2)) 
        && (listeTriangleSortante.get(1).c == listePoint.get(3)) //Vérification du second triangle.
        && (listeTriangleSortante.get(2).a == listePoint.get(3)) && (listeTriangleSortante.get(2).b == listePoint.get(4)) 
        && (listeTriangleSortante.get(2).c == listePoint.get(1))) //Vérification du troisième triangle.
    {      
      System.out.println("Test Réussi !"); 
    }
    else{
        System.out.println("Test Non-Réussi !");
    }

		Windows test = new Windows();
		
	}
}
