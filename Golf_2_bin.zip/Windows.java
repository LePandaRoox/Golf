import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/*
 * Classe Windows héritant de JFrame, permettant le réglage de la fenêtre et l'ajout de contenu comme des classes héritant de JPanel.
 */

public class Windows extends JFrame{

	private JPanel pan = new JPanel();
	private Bouton bouton = new Bouton("Triangularisation");
	private Button bouton2 = new Button("Jouer");
	private Button bouton3 = new Button("Quitter");
	
	public Windows(){
		Container contenu = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		this.setTitle("Jeux de Golf");
		this.setSize(500, 500);
		//Gère la fermeture de la fenêtre.
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Ajoute le JPanel permettant l'affichage
		pan.add(bouton);
		pan.add(bouton2);
		pan.add(bouton3);
		contenu.add(new Affichage());
		contenu.add(pan);
		this.getContentPane().add(contenu);
		//this.setContentPane(pan);
		//this.setContentPane(new Affichage());
		//Affiche la fenêtre : IMPORTANT
		this.setVisible(true);
	}

}
